import java.sql.*;


public class LeboncoinTest {

	public LeboncoinTest() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 * @throws ClassNotFoundException 
	 * @throws SQLException 
	 */
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Statement stmt;
		ResultSet rslt = null;
        Class.forName("org.h2.Driver");
        Connection conn = DriverManager.getConnection("jdbc:h2:~/test", "christophermb", "jeanjean");
        
        // add application code here
        stmt = conn.createStatement();
        
        stmt.execute("Drop table Ut");
        
        String str = "CREATE TABLE Ut(U_ID int,nom varchar(255),PRIMARY KEY(U_ID))";
        stmt.execute(str);
        
        str = "INSERT INTO Ut VALUES (1,'Ivan'),(2,'Qing')";
        stmt.execute(str);
        
        //Obtenir la description de tous les produits dont le prix de depart est 10.
        rslt = stmt.executeQuery("SELECT * FROM Produit WHERE prixDepart=10");
        //rslt.beforeFirst();
        while  (rslt.next()){
        System.out.println("La description de "+rslt.getString("nom")+" est : "+rslt.getString("description"));
        }
        
        //Obtenir le nom et la description de tous les objets vendus par Nada (en supposant qu'il n'y a qu'une seule Nada)
        rslt = stmt.executeQuery("SELECT * FROM Utilisateur WHERE nom='Nada'");
        //rslt.last();
        int sought_ID=0;
        while  (rslt.next()){
        	sought_ID = rslt.getInt("U_ID");
        }
        rslt = stmt.executeQuery("SELECT * FROM Produit WHERE V_ID="+sought_ID);
        rslt.beforeFirst();
        System.out.println("Nada Vend :");
        while  (rslt.next()){
        System.out.println(rslt.getString("nom")+" : "+rslt.getString("description"));
        }
        
        
        conn.close();
	}

}
